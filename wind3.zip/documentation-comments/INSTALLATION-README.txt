gia na kaneis install to wind-wna

ftiaxneis thn bash apo to directory database-schema
meta to petas se ena fakelo pou trexei php (px to htdocs)
kai ftiaxneis kai ton fakelo config


