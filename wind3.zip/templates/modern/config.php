<?php
// WiND Modern Theme Config
$template_config = array(
    'template' => array(
        'version' => 1,
        'minor_version' => 0,
        'name' => 'Modern Material',
        'css' => array('material.css'),
        'responsive' => true,
        'description' => 'Material Design inspired, mobile-friendly, responsive theme.'
    )
);
