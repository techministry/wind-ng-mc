<?php

$template_config = array(
	
	'template' => array(
		'version' => 1,
		'minor_version' => 0
		)

);

?>
