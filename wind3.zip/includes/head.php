<?php
/*
 * WiND - Wireless Nodes Database
 *
 * Copyright (C) 2005 Nikolaos Nikalexis <winner@cube.gr>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 dated June, 1991.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

class head {

	var $tpl;
	
	function __construct() {
		$this->tpl = array();
	}
	
	function add_extra($extra) {
		if (!isset($this->tpl['extra'])) $this->tpl['extra'] = '';
		$this->tpl['extra'] .= $extra;
	}
	
	function add_title($title) {
		$this->tpl['title'] = $title;
	}
	
	function add_base($href, $target="") {
		if (!isset($this->tpl['base'])) $this->tpl['base'] = array();
		array_push($this->tpl['base'], array('href' => $href, 'target' => $target));
	}
	
	function add_link($rel, $type="", $href="", $integrity="", $crossorigin="") {
		if (!isset($this->tpl['link'])) $this->tpl['link'] = array();
		// Support both old style (3 params) and new style (array)
		if (is_array($rel)) {
			array_push($this->tpl['link'], $rel);
		} else {
			$link = array('rel' => $rel, 'type' => $type, 'href' => $href);
			if ($integrity != '') $link['integrity'] = $integrity;
			if ($crossorigin != '') $link['crossorigin'] = $crossorigin;
			array_push($this->tpl['link'], $link);
		}
	}
	
	function add_meta($content, $name="", $http_equiv="", $scheme="") {
		if (!isset($this->tpl['meta'])) $this->tpl['meta'] = array();
		array_push($this->tpl['meta'], array('http-equiv' => $http_equiv, 'content' => $content, 'name' => $name, 'scheme' => $scheme));
	}
	
	function add_script($type,$src="", $integrity="", $crossorigin="") {
		if (!isset($this->tpl['script'])) $this->tpl['script'] = array();
		$script = array('type' => $type, 'src' => $src);
		if ($integrity != '') $script['integrity'] = $integrity;
		if ($crossorigin != '') $script['crossorigin'] = $crossorigin;
		array_push($this->tpl['script'], $script);
	}
	
	function output() {
		// Return HTML structure for head without rendering template yet
		// This prevents parse errors in template from breaking object construction
		$ret = "<title>" . (isset($this->tpl['title']) ? htmlspecialchars($this->tpl['title']) : 'WiND') . "</title>\n";
		
		if (isset($this->tpl['meta']) && is_array($this->tpl['meta'])) {
			foreach ($this->tpl['meta'] as $meta) {
				$ret .= '<meta ';
				if (!empty($meta['http-equiv'])) $ret .= 'http-equiv="' . htmlspecialchars($meta['http-equiv']) . '" ';
				if (!empty($meta['name'])) $ret .= 'name="' . htmlspecialchars($meta['name']) . '" ';
				if (!empty($meta['content'])) $ret .= 'content="' . htmlspecialchars($meta['content']) . '" ';
				if (!empty($meta['scheme'])) $ret .= 'scheme="' . htmlspecialchars($meta['scheme']) . '" ';
				$ret .= ">\n";
			}
		}
		
		if (isset($this->tpl['link']) && is_array($this->tpl['link'])) {
			foreach ($this->tpl['link'] as $link) {
				$ret .= '<link ';
				if (!empty($link['rel'])) $ret .= 'rel="' . htmlspecialchars($link['rel']) . '" ';
				if (!empty($link['type'])) $ret .= 'type="' . htmlspecialchars($link['type']) . '" ';
				if (!empty($link['href'])) $ret .= 'href="' . htmlspecialchars($link['href']) . '" ';
				if (!empty($link['integrity'])) $ret .= 'integrity="' . htmlspecialchars($link['integrity']) . '" ';
				if (!empty($link['crossorigin'])) $ret .= 'crossorigin="' . htmlspecialchars($link['crossorigin']) . '" ';
				$ret .= ">\n";
			}
		}
		
		if (isset($this->tpl['script']) && is_array($this->tpl['script'])) {
			foreach ($this->tpl['script'] as $script) {
				$ret .= '<script ';
				if (!empty($script['type'])) $ret .= 'type="' . htmlspecialchars($script['type']) . '" ';
				if (!empty($script['src'])) $ret .= 'src="' . htmlspecialchars($script['src']) . '" ';
				if (!empty($script['integrity'])) $ret .= 'integrity="' . htmlspecialchars($script['integrity']) . '" ';
				if (!empty($script['crossorigin'])) $ret .= 'crossorigin="' . htmlspecialchars($script['crossorigin']) . '" ';
				$ret .= '></script>' . "\n";
			}
		}
		
		if (isset($this->tpl['extra'])) {
			$ret .= $this->tpl['extra'];
		}
		
		return $ret;
	}

}

?>