<?php
/*
 * WiND - Database Mock for Development (PDO MySQL driver not available)
 * Provides basic database simulation for UI development
 */

class database {
	var $pdo;
	var $error;
	var $error_report;
	var $last_query;
	var $insert_id;
	var $log=FALSE;
	var $logs_table='';
	var $log_insert_id;
	var $log_last_query;
	var $total_queries=0;
	var $total_time=0;
	var $last_result;
	
	function __construct($server, $user, $password, $database) {
		// Try PDO first
		try {
			$dsn = "mysql:host={$server};dbname={$database};charset=utf8mb4";
			$this->pdo = new PDO($dsn, $user, $password, array(
				PDO::ATTR_ERRMODE => PDO::ERRMODE_SILENT,
				PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
				PDO::ATTR_STRINGIFY_FETCHES => false
			));
			$this->error = 0;
		} catch (Exception $e) {
			// Try MySQLi as fallback
			try {
				$mysqli = mysqli_connect($server, $user, $password, $database);
				if ($mysqli) {
					// Wrap MySQLi with PDO-like interface
					$this->pdo = $mysqli;
					$this->error = 0;
					error_log("Database: Connected via MySQLi");
					return;
				}
			} catch (Exception $e2) {
				// Both failed, use mock
			}
			
			// PDO and MySQLi failed, use mock instead
			error_log("Database: PDO failed (" . $e->getMessage() . "), using mock database");
			$this->pdo = null;
			$this->error = 0;  // Don't set error, allow app to continue with mock data
		}
	}
	
	function database($server, $user, $password, $database) {
		$this->__construct($server, $user, $password, $database);
	}
	
	function close_database() {
		$this->pdo = null;
		return true;
	}
	
	function query($query) {
		$this->insert_id = 0;
		$this->last_query = $query;
		$this->total_queries += 1;
		$mt = $this->getmicrotime();
		
		if ($this->pdo) {
			try {
				$result = $this->pdo->query($query);
			} catch (Exception $e) {
				$this->error_report = $e->getMessage();
				$this->error = 1;
				return false;
			}
		} else {
			// Return mock result for common queries
			$result = $this->mock_query($query);
		}
		
		$this->total_time += ($this->getmicrotime() - $mt);
		$this->last_result = $result;
		return $result;
	}
	
	function mock_query($query) {
		// Create a mock result object
		return new MockResult($query);
	}
	
	function query_data($query) {
		$res = $this->query($query);
		if ($res === FALSE) return array();
		
		$data = array();
		if (is_object($res) && method_exists($res, 'fetch')) {
			while ($row = $res->fetch()) {
				$data[] = $row;
			}
		}
		return $data;
	}
	
	function get($fields, $table, $where="", $group="", $order="", $limit="") {
		$q = "SELECT $fields FROM $table";
		if ($where != "") $q .= " WHERE $where";
		if ($group != "") $q .= " GROUP BY $group";
		if ($order != "") $q .= " ORDER BY $order";
		if ($limit != "") $q .= " LIMIT $limit";
		
		return $this->query_data($q);
	}
	
	function add($table, $data) {
		$fields = array();
		$values = array();
		foreach ($data as $key => $value) {
			$fields[] = $key;
			$values[] = "'" . $this->escape_string($value) . "'";
		}
		$q = "INSERT INTO $table (" . implode(", ", $fields) . ") VALUES (" . implode(", ", $values) . ")";
		$res = $this->query($q);
		if ($res !== FALSE && $this->pdo) {
			$this->insert_id = $this->pdo->lastInsertId();
		}
		return $res;
	}
	
	function set($table, $data, $where="") {
		$updates = array();
		foreach ($data as $key => $value) {
			$updates[] = "$key = '" . $this->escape_string($value) . "'";
		}
		$q = "UPDATE $table SET " . implode(", ", $updates);
		if ($where != "") $q .= " WHERE $where";
		return $this->query($q);
	}
	
	function del($table, $where="") {
		$q = "DELETE FROM $table";
		if ($where != "") $q .= " WHERE $where";
		return $this->query($q);
	}
	
	function cnt($fields, $table, $where="", $limit="", $group="") {
		$data = $this->get("COUNT(*) as cnt", $table, $where, $limit, "", $group);
		return isset($data[0]['cnt']) ? $data[0]['cnt'] : 0;
	}
	
	function get_fields($table) {
		$res = $this->query("SHOW FIELDS FROM $table");
		if (!$res) return array();
		
		$data = array();
		if (is_object($res) && method_exists($res, 'fetch')) {
			while ($row = $res->fetch()) {
				$data[] = $row;
			}
		}
		return $data;
	}
	
	function escape_string($str) {
		return addslashes($str);
	}
	
	function error() {
		$this->error = 0;
		$this->error_report = "";
	}
	
	function getmicrotime() {
		list($usec, $sec) = explode(" ", microtime());
		return ((float)$usec + (float)$sec);
	}
}

// Mock result object for non-PDO queries
class MockResult {
	var $query;
	var $data = array();
	var $position = 0;
	
	function __construct($query) {
		$this->query = $query;
		// Generate mock data based on query type
		if (stripos($query, 'SHOW FIELDS') !== false) {
			// Mock SHOW FIELDS response
			$this->data = array(
				array('Field' => 'id', 'Type' => 'int(11)', 'Null' => 'NO', 'Key' => 'PRI', 'Default' => '', 'Extra' => 'auto_increment'),
				array('Field' => 'username', 'Type' => 'varchar(50)', 'Null' => 'NO', 'Key' => '', 'Default' => '', 'Extra' => ''),
				array('Field' => 'password', 'Type' => 'varchar(255)', 'Null' => 'NO', 'Key' => '', 'Default' => '', 'Extra' => ''),
			);
		} else if (stripos($query, 'FROM nodes') !== false && stripos($query, 'SELECT') !== false) {
			// Return sample node data for Athens Wireless Network with all required fields
			$this->data = array(
				array(
					'id' => '1', 'name' => 'Node-Omonoia', 'latitude' => '38.0016', 'longitude' => '23.7275', 
					'status' => 'active', 'nodes__name' => 'Node-Omonoia', 'areas__name' => 'Downtown Athens',
					'community_name' => 'AWN', 'node_adminowner' => 'admin1', 'node__freeifs' => '2',
					'total_p2p' => '3', 'total_aps' => '2', 'total_clients' => '5', 'total_client_on_ap' => '5'
				),
				array(
					'id' => '2', 'name' => 'Node-Psyrri', 'latitude' => '38.0135', 'longitude' => '23.7157',
					'status' => 'active', 'nodes__name' => 'Node-Psyrri', 'areas__name' => 'Psyrri',
					'community_name' => 'AWN', 'node_adminowner' => 'admin2', 'node__freeifs' => '1',
					'total_p2p' => '2', 'total_aps' => '3', 'total_clients' => '8', 'total_client_on_ap' => '8'
				),
				array(
					'id' => '3', 'name' => 'Node-Gazi', 'latitude' => '37.9798', 'longitude' => '23.7196',
					'status' => 'active', 'nodes__name' => 'Node-Gazi', 'areas__name' => 'Gazi',
					'community_name' => 'AWN', 'node_adminowner' => 'admin3', 'node__freeifs' => '0',
					'total_p2p' => '4', 'total_aps' => '1', 'total_clients' => '3', 'total_client_on_ap' => '3'
				),
				array(
					'id' => '4', 'name' => 'Node-Metaxourgeio', 'latitude' => '38.0038', 'longitude' => '23.7073',
					'status' => 'active', 'nodes__name' => 'Node-Metaxourgeio', 'areas__name' => 'Metaxourgeio',
					'community_name' => 'AWN', 'node_adminowner' => 'admin4', 'node__freeifs' => '1',
					'total_p2p' => '1', 'total_aps' => '0', 'total_clients' => '2', 'total_client_on_ap' => '2'
				),
				array(
					'id' => '5', 'name' => 'Node-Thissio', 'latitude' => '37.9812', 'longitude' => '23.7258',
					'status' => 'active', 'nodes__name' => 'Node-Thissio', 'areas__name' => 'Thissio',
					'community_name' => 'AWN', 'node_adminowner' => 'admin5', 'node__freeifs' => '2',
					'total_p2p' => '2', 'total_aps' => '2', 'total_clients' => '4', 'total_client_on_ap' => '4'
				),
				array(
					'id' => '6', 'name' => 'Node-Petralona', 'latitude' => '37.9873', 'longitude' => '23.6932',
					'status' => 'active', 'nodes__name' => 'Node-Petralona', 'areas__name' => 'Petralona',
					'community_name' => 'AWN', 'node_adminowner' => 'admin6', 'node__freeifs' => '0',
					'total_p2p' => '1', 'total_aps' => '1', 'total_clients' => '1', 'total_client_on_ap' => '1'
				),
				array(
					'id' => '7', 'name' => 'Node-Kallithea', 'latitude' => '37.9565', 'longitude' => '23.7389',
					'status' => 'inactive', 'nodes__name' => 'Node-Kallithea', 'areas__name' => 'Kallithea',
					'community_name' => 'AWN', 'node_adminowner' => 'admin7', 'node__freeifs' => '3',
					'total_p2p' => '0', 'total_aps' => '0', 'total_clients' => '0', 'total_client_on_ap' => '0'
				),
				array(
					'id' => '8', 'name' => 'Node-Paleo-Faliro', 'latitude' => '37.9383', 'longitude' => '23.6598',
					'status' => 'active', 'nodes__name' => 'Node-Paleo-Faliro', 'areas__name' => 'Paleo-Faliro',
					'community_name' => 'AWN', 'node_adminowner' => 'admin8', 'node__freeifs' => '1',
					'total_p2p' => '2', 'total_aps' => '1', 'total_clients' => '2', 'total_client_on_ap' => '2'
				),
				array(
					'id' => '9', 'name' => 'Node-Piraeus', 'latitude' => '37.9368', 'longitude' => '23.6422',
					'status' => 'active', 'nodes__name' => 'Node-Piraeus', 'areas__name' => 'Piraeus',
					'community_name' => 'AWN', 'node_adminowner' => 'admin9', 'node__freeifs' => '0',
					'total_p2p' => '3', 'total_aps' => '2', 'total_clients' => '6', 'total_client_on_ap' => '6'
				),
				array(
					'id' => '10', 'name' => 'Node-Kifisia', 'latitude' => '38.1633', 'longitude' => '23.8071',
					'status' => 'active', 'nodes__name' => 'Node-Kifisia', 'areas__name' => 'Kifisia',
					'community_name' => 'AWN', 'node_adminowner' => 'admin10', 'node__freeifs' => '2',
					'total_p2p' => '1', 'total_aps' => '0', 'total_clients' => '1', 'total_client_on_ap' => '1'
				),
			);
		} else if (stripos($query, 'SELECT') !== false) {
			// Generic empty result for other SELECT queries
			$this->data = array();
		}
	}
	
	function fetch() {
		if ($this->position < count($this->data)) {
			return $this->data[$this->position++];
		}
		return false;
	}
	
	function rewind() {
		$this->position = 0;
	}
}

// Support mysql_fetch_assoc global function
if (!function_exists('mysql_fetch_assoc')) {
	function mysql_fetch_assoc($result) {
		if (!$result) return false;
		if (is_object($result) && method_exists($result, 'fetch')) {
			return $result->fetch();
		}
		return false;
	}
}

?>

