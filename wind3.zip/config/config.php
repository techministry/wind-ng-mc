<?php
/*
 * WiND - Wireless Nodes Database
 * Configuration File
 *
 * Copyright (C) 2005 Nikolaos Nikalexis <winner@cube.gr>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 dated June, 1991.
 *
 * WARNING: This file contains sensitive information. Keep it out of version control!
 * The config/ directory is already in .gitignore
 */

$config = array(
	
	// Database Configuration
	'db' => array(
		'server'   => 'wind3.wna.gr',
		'username' => 'wnagr_nodedb',
		'password' => 'dZs8wzEI1fRU',
		'database' => 'wnagr_wind05',
		'version'  => 0  // Set to 5 for MySQLi (PHP 5+), 0 for legacy MySQL
	),
	
	// Language Configuration
	'language' => array(
		'default' => 'english',
		'enabled' => array(
			'english' => TRUE,
			'greek' => TRUE
		)
	),
	
	// Templates Configuration
	'templates' => array(
		'path'           => ROOT_PATH.'templates/',
		// Theme selection: 'basic', 'dark', 'modern'
		'default'        => 'modern',
		'available'      => array('basic', 'dark', 'modern'),
		'compiled_path'  => ROOT_PATH.'templates/_compiled/'
	),
	
	// Smarty Configuration
	// Check multiple possible locations for Smarty installation
	'smarty' => array(
		'class' => (file_exists(ROOT_PATH.'vendor/smarty/smarty/libs/Smarty.class.php')) 
			? ROOT_PATH.'vendor/smarty/smarty/libs/Smarty.class.php'
			: (file_exists(ROOT_PATH.'templates/basic/smarty/libs/Smarty.class.php')
				? ROOT_PATH.'templates/basic/smarty/libs/Smarty.class.php'
				: ROOT_PATH.'vendor/autoload.php')  // Fallback to composer autoload
	),
	
	// Email/SMTP Configuration
	'mail' => array(
		'smtp'      => '',
		'smtp_port' => 25
    ),
	
	'dns' => array(
		'root_zone' => 'wn',
		'ns_zone' => 'ns.wn',
		'reverse_zone' => '10-in-addr.arpa',
#		'forward_zone_schema' => $root_path.'tools/dnszones-poller/domain-forward.schema',
#		'reverse_zone_schema' => $root_path.'tools/dnszones-poller/domain-reverse.schema'
#  /*
              'forward_zone_schema' => ROOT_PATH.'tools/dnszones-poller/wn.schema',
		'reverse_zone_schema' => ROOT_PATH.'tools/dnszones-poller/10.in-addr.arpa.schema'
#  */
  
		),
	
	'folders' => array(
		'photos' => ROOT_PATH.'files/photos/'
		),
	
	'mail' => array(
		'smtp' => '', // if not set default used from php.ini file
		'smtp_port' => '25',
		'from' => 'hostmaster@wna.gr',
		'from_name' => 'WiND Hostmaster'
		),
	
 'srtm' => array(
		'path' => ROOT_PATH.'files/srtm/'
		),
  
  
	'gmap' => array(
	'server' => 'maps.google.com',
	'maps_available' => array(
                        'satellite' => true,
                        'normal' => true,
                        'hybrid' => true,
			    'physical' => true,
			//Sample scripts for custom image map server can be found in the tools subdirectory
                        /*'custom_maps' => array(
                              0 => array(
                                      'url' => 'http://server.example.org/maps/index.php?',
                                      'name' => 'Custom1',
                                      'coordinates_type' => 'map'
                                      ),
                                1 => array(
                                        'url' => 'http://server.example.org/maps/index.php?',
                                        'name' => 'Custom2',
                                        'coordinates_type' => 'satellite'
                                        ),
                                ),*/
                        'default' => 'physical'
                        ),
	 'api' => '2.128e',
 	 'keys' => array( // Domains must be as in $_SERVER['SERVER_NAME'] variable
			'www.wna.gr/wind' => 'ABQIAAAAjSH1V6ibZuGs3cdRiYG9VBSZ0kGqljnkDGVnCwxRAlkIjxxlwhQYz4g4ARZVm2vEkmN8WZ1K7YdGrw',
			'wind.wna.gr' =>'ABQIAAAAjSH1V6ibZuGs3cdRiYG9VBSeVKz1-uQ_gZwmTCDZ9NOhfpQDHxQWBap-cbopYsHY_eaNZsJhtGObEQ',
			'www.wna.wn/wind' =>'ABQIAAAAjSH1V6ibZuGs3cdRiYG9VBS-8lZUJe15tAqZKeqkF7ga_7CtFxStLtSMF6PqAvSHLXZxCxs6MSj6-Q',
			'www.wna.wn' =>'ABQIAAAAjSH1V6ibZuGs3cdRiYG9VBSaaX-SS-6m2zQDBRITBjH8_1SJVRTWy6CC6WYD9EMws7GZpsjffXPrnQ',
   	),
#ABQIAAAAjSH1V6ibZuGs3cdRiYG9VBS-8lZUJe15tAqZKeqkF7ga_7CtFxStLtSMF6PqAvSHLXZxCxs6MSj6-Q
		'bounds' => array(
#			'min_latitude' => MINLAT_GPS_COORDINATE,
#			'min_longitude' => MINLON_GPS_COORDINATE,
#			'max_latitude' => MAXLAT_GPS_COORDINATE,
#			'max_longitude' => MAXLON_GPS_COORDINATE
  	                #'min_latitude' => 40.490,
                       #'min_longitude' => 22.823,
                       #'max_latitude' => 40.740,
                       #'max_longitude' => 23.050

                       'min_latitude' => 36.029,
                       'min_longitude' => 17.517,
                       'max_latitude' => 42.277,
                       'max_longitude' => 28.608
			)
		),
      'debug' => array(
		'enabled' =>TRUE
		)

);

?>
